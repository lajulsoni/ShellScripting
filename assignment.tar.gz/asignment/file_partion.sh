fdisk $1
fdisk $1
#mkfs 'fat32 $1
#tar -cvf $2 $2.tar.gz
#cd $1
#mkdir new_folder
#cd -
