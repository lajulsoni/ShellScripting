n[0]="lal"
n[1]="pila"
n[2]="nila"
n[3]="gila"

echo "First index :${n[0]}"
echo "all : ${n[@]}"
v="welcome to kingdom"
echo "Yo : ${v[*]}"
