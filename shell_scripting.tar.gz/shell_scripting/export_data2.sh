# !/bin/sh
export var2=2000
echo $var2
. ./export_data.sh
echo $var2
