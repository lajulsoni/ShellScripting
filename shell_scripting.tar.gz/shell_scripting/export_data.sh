# !/bin/sh

export var1=1000
echo $var1
. ./export_data2.sh
