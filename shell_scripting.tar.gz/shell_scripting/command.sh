#!/bin/sh
echo ls output
ls
echo pwd output
pwd
echo ls -a output
ls -a
echo ls -la output
ls -la
echo ps output
ps
echo ps -e output
ps -e
echo clear output
clear
