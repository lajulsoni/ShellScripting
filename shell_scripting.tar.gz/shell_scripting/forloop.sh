# !/bin/sh
echo enter num value :
read num
for (( i=0; i<=num; i=i+1 ))
do
  echo $i
done
