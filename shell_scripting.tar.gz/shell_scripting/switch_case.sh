# !/bin/sh
case $1 in
  car) echo $1 for rent is availble;;
    bike) echo $1 for rent is availble;;
    jeep) echo $1 for rent is availble;;
    truck) echo $1 for rent is availble;;
    *) echo $1 nothing is availble;;
  esac
